#include <iostream>
#include <stdio.h>
#include<stdlib.h>
#include <time.h>
#include<sstream>
using namespace std;

int main() {
	int guess;
	int randNum;
	int attempts = 0;
	bool win;
	
	srand(time(NULL));

	randNum = rand() % 100 + 1;


	while (!win) {
		string test;
		cout << "Enter Number Guess: ";
		getline(cin, test);
		stringstream ss(test);
		ss >> guess;

		if (guess == randNum) {
			cout << "Correct! the number was " << randNum << " this took you " 
					<< attempts + 1 << " attempts!" << endl;
			win = true;
		} else {
			if (guess > randNum) {
				cout << "Too High ";
				attempts++;
			} else {
				cout << "Too Low ";
				attempts++;
			}
		}
	}
}